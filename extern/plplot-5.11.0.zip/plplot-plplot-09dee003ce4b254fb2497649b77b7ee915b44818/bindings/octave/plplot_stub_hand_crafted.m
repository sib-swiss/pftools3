# Hand-crafted file to set up running swig-generated octave bindings for
# PLplot.  So far it is extremely simple;

plplot_octave;
