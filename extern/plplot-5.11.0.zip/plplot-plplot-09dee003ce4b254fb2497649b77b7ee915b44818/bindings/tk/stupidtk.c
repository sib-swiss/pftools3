int Tcl_AppInit()
{
    return 0;
}
