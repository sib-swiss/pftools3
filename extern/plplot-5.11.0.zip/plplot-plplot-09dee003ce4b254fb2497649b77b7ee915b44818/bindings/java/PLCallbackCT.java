
package plplot.core;

public interface PLCallbackCT
{
    public void coordTransform( double x, double y, double xt[], double yt[], Object data );
};
